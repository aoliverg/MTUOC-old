/*************************************************************************
*                                                                        *
*  (C) Copyright 2004. Media Research Centre at the                      *
*  Sociology and Communications Department of the                        *
*  Budapest University of Technology and Economics.                      *
*                                                                        *
*  Developed by Daniel Varga.                                            *
*                                                                        *
*************************************************************************/

#ifndef __HUNGLISH_ALIGNMENT_SIMILARITYEVALUATOR_H
#define __HUNGLISH_ALIGNMENT_SIMILARITYEVALUATOR_H

namespace Hunglish
{

} // namespace Hunglish

#endif // #define __HUNGLISH_ALIGNMENT_SIMILARITYEVALUATOR_H
