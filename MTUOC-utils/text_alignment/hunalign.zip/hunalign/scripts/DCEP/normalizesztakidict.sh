#!/bin/bash

awk '{ print $2,"@",$1 }'
